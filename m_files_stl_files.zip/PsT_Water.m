clear all;
clc;

w= Solution('liquidvapor.cti', 'water');

T_min = 300;
T_max = 647.095; %Critical Point of Water is 647.096 K

set(w,'T',T_min,'Vapor',0);
vmin = 1/density(w);
set(w,'T',T_max,'Vapor',1.0);
vmax = 1/density(w);


setState_TV(w, [T_min;vmin]);
smin = entropy_mass(w);
setState_TV(w, [T_max;vmax]);
smax = entropy_mass(w);

T_n= 100;
delta_T = (T_max-T_min)/T_n;
s_n = 100;
delta_logs = log10(smax/smin)/s_n;

logsmin = log10(smin);

s = zeros(s_n,1);
T = zeros(T_n,1);
p = zeros(s_n,T_n);

for i= 1:s_n
    logs(i) = logsmin + (i-1)*delta_logs;
    s = 10.0^(logs(i));
    for k = 1:T_n
        T(k) = T_min + (k-1)*delta_T;
        setState_ST(w,[s; T(k)])
        logp(k,i) = log10(pressure(w));
    end
end

surf(logs,T,logp);
xlabel('logs');
ylabel('T');
zlabel('logp');

%colormap(black);
%shading interp;

surf2solid(logs,T,logp);
stlwrite('print1.stl',surf2solid(logs,T,logp));