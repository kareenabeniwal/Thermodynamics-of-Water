clear all;
clc;

w= Solution('liquidvapor.cti', 'water');

T_min= 300;
T_max= 647.10; %Critical Point of Water is 647.096 K

set(w,'T',T_min,'Vapor',0);
vmin = 1/density(w);
set(w,'T',T_max,'Vapor',1.0);
vmax = 1/density(w);


setState_TV(w, [T_min;vmin]);
hmin = enthalpy_mass(w);
setState_TV(w, [T_max;vmax]);
hmax = enthalpy_mass(w);

T_n= 100;
delta_T = (T_max-T_min)/T_n;
h_n = 100;
delta_logh = log10(hmax/hmin)/h_n;

loghmin = log10(hmin);

h = zeros(h_n,1);
T = zeros(T_n,1);
p = zeros(h_n,T_n);

for i= 1:h_n
    logh(i) = loghmin + (i-1)*delta_logh;
    h = 10.0^(logh(i));
    for k = 1:T_n
        T(k) = T_min + (k-1)*delta_T;
        setState_TH(w,[T(k);h])
        logp(k,i) = log10(pressure(w));
    end
end

surf(log((h)),T,logp);
xlabel('logh');
ylabel('T');
zlabel('logp');
%colormap(black);
%shading interp;

surf2solid(log(h),T,logp);
stlwrite('print1.stl',surf2solid(log(h),T,logp));