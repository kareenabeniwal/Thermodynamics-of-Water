
W=Solution('liquidvapor.cti','water');
tmin = minTemp(W) + 0.01;
tmax = maxTemp(W) + 0.01;

set(W,'T',tmin,'Vapor',0);
vmin = 0.5/density(W);
set(W,'T',tmin,'Vapor',1.0);
vmax = 10/density(W);

nt = 100;
dt = (tmax-tmin)/nt;
nv = 100;
dlogv = log10(vmax/vmin)/nv;
logvmin = log10(vmin);
v = zeros(nv,1);
t = zeros(nt,1);
p = zeros(nv,nt);

for n = 1:nv
    logv(n) = logvmin + (n-1)*dlogv;
    v = 10.0^logv(n);
    for m = 1:nt
        t(m) = tmin + (m-1)*dt;
        set(W,'T',t(m),'V',v);
        logp(m,n) = log10(pressure(W));
    end
end
surf(logv,t,logp);
%colormap(gray);
%shading interp;
surf2solid(logv,t,logp);
stlwrite('print1.stl',surf2solid(logv,t,logp));




